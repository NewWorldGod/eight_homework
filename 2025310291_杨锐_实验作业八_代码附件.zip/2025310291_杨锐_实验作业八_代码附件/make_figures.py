# -*- coding: utf-8 -*-
"""从 runs_distill/*.json 生成报告用图，不重新训练。"""

import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "runs_distill")

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Noto Sans SC"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 140
plt.rcParams["savefig.dpi"] = 180
plt.rcParams["axes.grid"] = True
plt.rcParams["grid.alpha"] = 0.25
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False


def load(name):
    with open(os.path.join(OUT, name), "r", encoding="utf-8") as f:
        return json.load(f)


def plot_curves():
    tea = load("results_teacher.json")
    allr = load("results_all.json")
    fig, ax = plt.subplots(1, 2, figsize=(10.2, 3.8))

    tcurve = tea["teacher"]["curve"]
    ax[0].plot(range(1, len(tcurve) + 1), tcurve, label="教师", lw=1.4,
               color="#1f77b4")
    for key, lab, color in (("scratch", "从零学生", "#ff7f0e"),
                            ("kd", "蒸馏学生", "#2ca02c")):
        c = allr[key]["curve"]
        ax[0].plot(range(1, len(c) + 1), c, label=lab, lw=1.3, color=color)
    ax[0].set_xlabel("训练迭代步")
    ax[0].set_ylabel("训练损失")
    ax[0].set_title("(a) 训练损失曲线")
    ax[0].legend(fontsize=8, frameon=False)
    ax[0].set_ylim(0, 6.2)

    names = ["教师", "从零学生", "蒸馏学生"]
    vals = [tea["teacher"]["val_loss"], allr["scratch"]["val_loss"],
            allr["kd"]["val_loss"]]
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]
    bars = ax[1].bar(names, vals, color=colors, width=0.58)
    for b, v in zip(bars, vals):
        ax[1].text(b.get_x() + b.get_width() / 2, v + 0.02, "%.4f" % v,
                   ha="center", va="bottom", fontsize=9)
    ax[1].set_ylabel("留出集 loss")
    ax[1].set_title("(b) 留出集 loss")
    ax[1].set_ylim(0, max(vals) * 1.25)
    ax[1].text(0.03, 0.95, "PPL: %.2f / %.2f / %.2f" % (
        tea["teacher"]["ppl"], allr["scratch"]["ppl"], allr["kd"]["ppl"]),
        transform=ax[1].transAxes, va="top", fontsize=8,
        bbox=dict(boxstyle="round,pad=0.25", facecolor="white", alpha=0.75,
                  edgecolor="#cccccc"))
    fig.tight_layout()
    path = os.path.join(OUT, "curves.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print("[fig]", path)


def plot_heatmap():
    ab = load("results_ablate.json")
    Ts = [1, 2, 4, 8]
    As = [0.3, 0.5, 0.7, 0.9]
    grid = np.zeros((len(Ts), len(As)))
    for r in ab["ablation"]:
        grid[Ts.index(r["T"]), As.index(r["alpha"])] = r["val_loss"]
    best = ab["best"]

    fig, ax = plt.subplots(figsize=(6.4, 5.2))
    im = ax.imshow(grid, cmap="RdYlGn_r", aspect="auto")
    ax.set_xticks(range(len(As)))
    ax.set_xticklabels(["α=%.1f" % a for a in As])
    ax.set_yticks(range(len(Ts)))
    ax.set_yticklabels(["T=%d" % t for t in Ts])
    ax.set_xlabel("蒸馏权重 α")
    ax.set_ylabel("温度 T")
    ax.set_title("T × α 消融（留出集 loss，越低越好）")
    for i in range(len(Ts)):
        for j in range(len(As)):
            rgba = im.cmap(im.norm(grid[i, j]))
            lum = 0.299 * rgba[0] + 0.587 * rgba[1] + 0.114 * rgba[2]
            color = "white" if lum < 0.48 else "#1f2937"
            ax.text(j, i, "%.4f" % grid[i, j], ha="center", va="center",
                    fontsize=9, color=color, fontweight="bold")
    bi = Ts.index(best["T"])
    bj = As.index(best["alpha"])
    ax.add_patch(plt.Rectangle((bj - 0.5, bi - 0.5), 1, 1, fill=False,
                               edgecolor="#111827", lw=3))
    ax.text(bj, bi - 0.36, "最优", ha="center", va="bottom", fontsize=8,
            color="white", fontweight="bold")
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("val loss")
    fig.tight_layout()
    path = os.path.join(OUT, "ablation_heatmap.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print("[fig]", path)


def plot_scale():
    sc = load("results_scale.json")
    rows = sorted(sc["scale"], key=lambda r: r["C"])
    Cs = [r["C"] for r in rows]
    params = [r["teacher_params"] / 1e6 for r in rows]
    tvals = [r["teacher_val_loss"] for r in rows]
    svals = [r["scratch_val_loss"] for r in rows]
    kvals = [r["kd_val_loss"] for r in rows]
    gains = [r["gain_abs"] for r in rows]

    fig, ax = plt.subplots(1, 2, figsize=(10.2, 4.25))
    ax[0].plot(params, tvals, "o-", label="教师", color="#1f77b4", lw=1.5)
    ax[0].plot(params, svals, "s--", label="从零学生", color="#ff7f0e", lw=1.3)
    ax[0].plot(params, kvals, "^-", label="蒸馏学生", color="#2ca02c", lw=1.5)
    for x, y, c in zip(params, tvals, Cs):
        ax[0].annotate("C=%d" % c, (x, y), textcoords="offset points",
                       xytext=(4, 6), fontsize=8)
    ax[0].set_xlabel("教师参数量（M）")
    ax[0].set_ylabel("留出集 loss")
    ax[0].set_title("(a) 教师强度 vs 留出集 loss")
    ax[0].legend(fontsize=8, frameon=False)

    bars = ax[1].bar(["C=%d" % c for c in Cs], gains,
                     color=["#9ecae1", "#2ca02c", "#9ecae1"], width=0.58)
    for b, g in zip(bars, gains):
        ax[1].text(b.get_x() + b.get_width() / 2, g + 0.001, "%.4f" % g,
                   ha="center", va="bottom", fontsize=9)
    ax[1].set_ylabel("KD 绝对收益（scratch - KD）")
    ax[1].set_title("(b) 蒸馏收益随教师规模变化")
    ax[1].set_ylim(0, max(gains) * 1.25)
    fig.tight_layout()
    path = os.path.join(OUT, "teacher_scale.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print("[fig]", path)


def write_summary():
    tea = load("results_teacher.json")
    allr = load("results_all.json")
    ab = load("results_ablate.json")
    fit = load("results_fitnet.json")
    selfkd = load("results_selfkd.json")
    quant = load("results_quant.json")
    scale = load("results_scale.json")

    lines = []
    lines.append("=== 主实验 ===")
    lines.append("data: %s" % allr["data"])
    lines.append("teacher: %s" % {k: v for k, v in tea["teacher"].items() if k != "curve"})
    lines.append("scratch: %s" % {k: v for k, v in allr["scratch"].items() if k != "curve"})
    lines.append("kd: %s" % {k: v for k, v in allr["kd"].items() if k != "curve"})
    lines.append("comparison: %s" % allr["comparison"])
    lines.append("samples: %s" % allr["samples"])
    lines.append("=== 消融 ===")
    lines.append("best: %s" % ab["best"])
    lines.append("worst: %s" % ab["worst"])
    for r in ab["ablation"]:
        lines.append("T=%d a=%.1f: %.6f" % (r["T"], r["alpha"], r["val_loss"]))
    lines.append("=== 拓展 ===")
    lines.append("fitnet: %s" % {k: v for k, v in fit["fitnet"].items() if k != "curve"})
    lines.append("self_teacher: %s" % selfkd["self_teacher"])
    lines.append("selfkd: %s" % {k: v for k, v in selfkd["selfkd"].items() if k != "curve"})
    lines.append("quant: %s" % quant["quant"])
    lines.append("scale: %s" % scale["scale"])
    text = "\n".join(lines)
    path = os.path.join(OUT, "summary.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text + "\n")
    print("[summary]", path)
    print(text)


if __name__ == "__main__":
    plot_curves()
    plot_heatmap()
    plot_scale()
    write_summary()
