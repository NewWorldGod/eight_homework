# -*- coding: utf-8 -*-
"""读取 runs_distill 的真实结果，填写实验报告模板并导出 DOCX。"""

import json
import os
import shutil

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from docx.table import Table
from docx.text.paragraph import Paragraph

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "runs_distill")
TEMPLATE = os.path.join(
    BASE, "作业八_自制语言模型知识蒸馏_实验报告（空白模板）.docx")
DST = os.path.join(BASE, "2025310291_杨锐_实验作业八.docx")

BODY = RGBColor(0x4B, 0x55, 0x63)
INK = RGBColor(0x1F, 0x29, 0x37)
HEAD_FONT = "Arial"
BODY_FONT = "Times New Roman"
EAST = "宋体"
CENTER = WD_ALIGN_PARAGRAPH.CENTER
LEFT = WD_ALIGN_PARAGRAPH.LEFT


# ============================================================
# JSON
# ============================================================
def load(name):
    with open(os.path.join(OUT, name), "r", encoding="utf-8") as f:
        return json.load(f)


teacher = load("results_teacher.json")
allr = load("results_all.json")
ab = load("results_ablate.json")
fit = load("results_fitnet.json")
selfkd = load("results_selfkd.json")
quant = load("results_quant.json")
scale = load("results_scale.json")
quick = load(os.path.join("quick", "results_all.json"))

T = teacher["teacher"]
S = allr["scratch"]
K = allr["kd"]
CMP = allr["comparison"]
FIT = fit["fitnet"]
ST = selfkd["self_teacher"]
SK = selfkd["selfkd"]
Q = quant["quant"]
SCALE_ROWS = sorted(scale["scale"], key=lambda r: r["C"])
BEST = ab["best"]
WORST = ab["worst"]
T1 = [r for r in ab["ablation"] if r["T"] == 1]
T1_SPREAD = max(r["val_loss"] for r in T1) - min(r["val_loss"] for r in T1)
FIT_GAIN_KD = K["val_loss"] - FIT["val_loss"]
FIT_GAIN_SCRATCH = S["val_loss"] - FIT["val_loss"]
SELF_GAIN_SCRATCH = S["val_loss"] - SK["val_loss"]
SELF_GAIN_KD = K["val_loss"] - SK["val_loss"]


def f4(x):
    return "%.4f" % x


def f3(x):
    return "%.3f" % x


def f2(x):
    return "%.2f" % x


def f1(x):
    return "%.1f" % x


def pct(x):
    return "%.2f%%" % x


# ============================================================
# 基础排版工具
# ============================================================
def set_run_font(run, size=10.5, bold=False, color=BODY,
                 font=BODY_FONT, east=EAST):
    run.font.name = font
    run.font.size = Pt(size)
    run.bold = bold
    run.font.color.rgb = color
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    rFonts.set(qn("w:ascii"), font)
    rFonts.set(qn("w:hAnsi"), font)
    rFonts.set(qn("w:eastAsia"), east)


def clear_runs(p):
    for child in list(p._p):
        if child.tag in (qn("w:r"), qn("w:hyperlink")):
            p._p.remove(child)


def set_par(p, text, size=10.5, bold=False, color=BODY,
            font=BODY_FONT, east=EAST, align=None,
            before=None, after=4, line=1.25):
    clear_runs(p)
    run = p.add_run(text)
    set_run_font(run, size=size, bold=bold, color=color, font=font, east=east)
    pf = p.paragraph_format
    if before is not None:
        pf.space_before = Pt(before)
    if after is not None:
        pf.space_after = Pt(after)
    if line is not None:
        pf.line_spacing = line
    if align is not None:
        p.alignment = align
    return p


def new_para_after(anchor, text="", **kwargs):
    p_el = OxmlElement("w:p")
    anchor._p.addnext(p_el)
    p = Paragraph(p_el, anchor._parent)
    if text:
        set_par(p, text, **kwargs)
    return p


def new_para_before(anchor, text="", **kwargs):
    p_el = OxmlElement("w:p")
    anchor._p.addprevious(p_el)
    p = Paragraph(p_el, anchor._parent)
    if text:
        set_par(p, text, **kwargs)
    return p


def new_para_before_table(table, text="", **kwargs):
    p_el = OxmlElement("w:p")
    table._tbl.addprevious(p_el)
    p = Paragraph(p_el, table._parent)
    if text:
        set_par(p, text, **kwargs)
    return p


def new_para_after_table(table, text="", **kwargs):
    p_el = OxmlElement("w:p")
    table._tbl.addnext(p_el)
    p = Paragraph(p_el, table._parent)
    if text:
        set_par(p, text, **kwargs)
    return p


def find_par(doc, needle):
    for p in doc.paragraphs:
        if needle in p.text:
            return p
    raise KeyError("找不到段落：%s" % needle)


def set_cell(cell, text, size=10.5, bold=False, color=INK, align=CENTER,
             font=BODY_FONT, east=EAST, line=1.1):
    for p in list(cell.paragraphs)[1:]:
        p._element.getparent().remove(p._element)
    p = cell.paragraphs[0]
    set_par(p, text, size=size, bold=bold, color=color, font=font, east=east,
            align=align, before=0, after=0, line=line)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def set_cell_width(cell, cm):
    cell.width = Cm(cm)
    tcPr = cell._tc.get_or_add_tcPr()
    tcW = tcPr.find(qn("w:tcW"))
    if tcW is None:
        tcW = OxmlElement("w:tcW")
        tcPr.append(tcW)
    tcW.set(qn("w:type"), "dxa")
    tcW.set(qn("w:w"), str(int(cm * 567)))


def set_col_widths(table, widths):
    table.autofit = False
    for j, w in enumerate(widths):
        table.columns[j].width = Cm(w)
        for row in table.rows:
            set_cell_width(row.cells[j], w)


def add_caption_before_table(table, text):
    return new_para_before_table(
        table, text, size=10.5, bold=True, color=BODY, font=HEAD_FONT,
        align=CENTER, before=3, after=3, line=1.1)


def add_caption_after(anchor, text):
    return new_para_after(
        anchor, text, size=10.5, bold=True, color=BODY, font=HEAD_FONT,
        align=CENTER, before=3, after=6, line=1.1)


def add_heading(anchor, text):
    return new_para_before(
        anchor, text, size=12, bold=True, color=INK, font=HEAD_FONT,
        align=LEFT, before=9, after=4, line=1.15)


def add_figure_before(anchor, path, width_cm):
    p_el = OxmlElement("w:p")
    anchor._p.addprevious(p_el)
    p = Paragraph(p_el, anchor._parent)
    p.alignment = CENTER
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.line_spacing = 1.0
    run = p.add_run()
    run.add_picture(path, width=Cm(width_cm))
    return p


def insert_image_cell(cell, path, width_cm):
    for p in list(cell.paragraphs)[1:]:
        p._element.getparent().remove(p._element)
    p = cell.paragraphs[0]
    clear_runs(p)
    p.alignment = CENTER
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.line_spacing = 1.0
    run = p.add_run()
    run.add_picture(path, width=Cm(width_cm))
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def add_code_block(anchor, lines):
    p_el = OxmlElement("w:p")
    anchor._p.addnext(p_el)
    p = Paragraph(p_el, anchor._parent)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.left_indent = Cm(0.2)
    p.paragraph_format.keep_together = True
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), "F3F4F6")
    pPr.append(shd)
    for i, line in enumerate(lines):
        run = p.add_run(line)
        set_run_font(run, size=8.5, color=INK, font="Consolas", east=EAST)
        if i < len(lines) - 1:
            run.add_break()
    return p


def add_table_before_par(anchor, rows, widths, header=True):
    table = doc.add_table(rows=len(rows), cols=len(rows[0]))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            cell = table.cell(i, j)
            set_cell_width(cell, widths[j])
            set_cell(cell, value, size=9.0 if i else 9.5,
                     bold=(i == 0 and header),
                     align=LEFT if j in (1, 3) else CENTER)
    set_col_widths(table, widths)
    anchor._p.addprevious(table._tbl)
    return table


def add_field(run, instr):
    fld1 = OxmlElement("w:fldChar")
    fld1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText")
    it.set(qn("xml:space"), "preserve")
    it.text = instr
    fld2 = OxmlElement("w:fldChar")
    fld2.set(qn("w:fldCharType"), "separate")
    t = OxmlElement("w:t")
    t.text = "1"
    fld3 = OxmlElement("w:fldChar")
    fld3.set(qn("w:fldCharType"), "end")
    run._r.append(fld1)
    run._r.append(it)
    run._r.append(fld2)
    run._r.append(t)
    run._r.append(fld3)


def add_footer(doc):
    footer = doc.sections[0].footer
    p = footer.paragraphs[0]
    p.alignment = CENTER
    clear_runs(p)
    r = p.add_run("实验报告　第 ")
    set_run_font(r, 9, color=BODY)
    r = p.add_run()
    set_run_font(r, 9, color=BODY)
    add_field(r, "PAGE")
    r = p.add_run(" 页 / 共 ")
    set_run_font(r, 9, color=BODY)
    r = p.add_run()
    set_run_font(r, 9, color=BODY)
    add_field(r, "NUMPAGES")
    r = p.add_run(" 页")
    set_run_font(r, 9, color=BODY)

    settings = doc.settings.element
    if settings.find(qn("w:updateFields")) is None:
        uf = OxmlElement("w:updateFields")
        uf.set(qn("w:val"), "true")
        settings.append(uf)


def no_split_rows(table, header=False):
    for i, row in enumerate(table.rows):
        trPr = row._tr.get_or_add_trPr()
        if trPr.find(qn("w:cantSplit")) is None:
            trPr.append(OxmlElement("w:cantSplit"))
        if i == 0 and header and trPr.find(qn("w:tblHeader")) is None:
            trPr.append(OxmlElement("w:tblHeader"))


# ============================================================
# 开始填表
# ============================================================
doc = Document(TEMPLATE)

t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11 = doc.tables

# ---------- 封面 ----------
set_cell(t0.rows[2].cells[1], "杨锐 / 2025310291", size=10.5, align=LEFT)
set_cell(t0.rows[3].cells[1], "预计算机2班", size=10.5, align=LEFT)
set_cell(t0.rows[4].cells[1], "2026 年 11 月 6 日", size=10.5, align=LEFT)
set_cell(t0.rows[5].cells[1],
         "CPU（AMD Ryzen 9 8945HX，8 线程）/ Python 3.14.0 / "
         "PyTorch 2.14.0+cu130（纯 CPU 运行）", size=10.0, align=LEFT)

# ---------- 二、实验环境 ----------
env_rows = [
    ["操作系统", "Windows 11 家庭版 中文版（10.0.26200）"],
    ["Python 版本", "3.14.0"],
    ["PyTorch 版本", "2.14.0+cu130（仅 CPU 模式，未调用 GPU）"],
    ["CPU 型号 / 核心数", "AMD Ryzen 9 8945HX，16 核 / 32 线程；训练固定 8 线程"],
    ["内存", "31.3 GB；实测进程峰值 800.6 MB"],
    ["是否使用 GPU", "否（模型与张量均在 CPU；torch 为 CUDA 构建但未使用）"],
]
for i, (k, v) in enumerate(env_rows, start=1):
    set_cell(t1.rows[i].cells[0], k, size=10.5, bold=False, align=LEFT)
    set_cell(t1.rows[i].cells[1], v, size=10.5, align=LEFT)
p_env = new_para_after_table(
    t1,
    "指南建议 Python 3.10–3.12 / PyTorch 2.15.0+cpu；本机 3.14.0 / 2.14.0+cu130 实测兼容，"
    "张量全部在 CPU（cuda_available=True 仅说明驱动存在）。matplotlib 3.10.9；本机 16 核/32 线程、"
    "固定 8 线程，表中时间为本机墙钟，不作跨机器比较。",
    size=10.5, after=4)
p_env.paragraph_format.keep_together = True

# ---------- 一、实验目的 ----------
purpose = [
    "（1）把“教师模型 → 软标签 → 学生模型”的知识蒸馏流程完整跑通，并能从梯度与信息两个角度说明软标签为什么能提升小模型。",
    "（2）亲手实现带温度 T 的蒸馏损失，验证 KL 方向、(B,T,V)→(B·T,V) 的 reshape 和 T² 缩放，避免“能跑但梯度错了”的假实现。",
    "（3）在纯 CPU 上完成 0.737 M → 0.147 M、约 5× 压缩的真实蒸馏，并用同架构、同初始化、同数据顺序、同步数的对照量化收益。",
    "（4）通过 4×4 的 T×α 消融理解温度过低/过高、权重过大/过小时的失效边界，并能回到损失公式解释。",
    "（5）用 FitNet、自蒸馏、动态量化和教师规模扫描，建立“蒸馏—量化—剪枝”三类压缩技术的整体认识。",
]
p = find_par(doc, "（请用自己的语言概括")
set_par(p, purpose[0], size=10.5, after=4)
anchor = p
for text in purpose[1:]:
    anchor = new_para_after(anchor, text, size=10.5, after=4)

# ---------- 三、实验原理 ----------
principle = [
    "硬标签只告诉模型“下一个字是光”，其余 321 个类全为 0；软标签给出的是整个 322 维分布，"
    "例如“光 0.82、色 0.11、夜 0.03……”。这些残留在错误类上的概率就是 Hinton 所说的暗知识："
    "它编码了“光—色—夜”的相似性，相当于把教师的类别结构先验传给学生。",
    "带温度的 softmax 为 p_i^T = exp(z_i/T) / Σ_j exp(z_j/T)。T=1 时接近 one-hot；T>1 时分布被平滑，"
    "类间差异被放大到可学习；T 过大（如 20）则趋近均匀，退化成噪声。",
    "总损失 L = (1−α)·CE(y,p_s) + α·T²·KL(p_t^T ‖ p_s^T)：CE 用真实标签保证正确性，KL 用教师软标签"
    "提供结构；KL 方向是教师分布到学生 log-softmax，计算前要把 (B,T,V) reshape 成 (B·T,V)。"
    "T² 不能漏：对 z_s 求导时 softmax(z_s/T) 带来 1/T 因子，KL 里又有一个 1/T，梯度与 T² 成反比；"
    "乘 T² 正好抵消，换 T 时不必重调学习率。α 权衡硬标签与教师：α=0 退化为普通训练，α 过大则硬标签"
    "约束被丢掉、教师误差被放大。",
]
p = find_par(doc, "（简述知识蒸馏的基本思想")
set_par(p, principle[0], size=10.5, after=4)
anchor = p
for text in principle[1:]:
    anchor = new_para_after(anchor, text, size=10.5, after=4)

# ---------- 四、实验步骤 ----------
cmd_rows = [
    ["1. 环境自检", "python distill_lm.py --mode quick", "成功（退出码 0）",
     "%.1f s" % quick["meta"]["wall_time_s"]],
    ["2. 训练教师", "python distill_lm.py --mode teacher --retrain", "成功",
     "%.1f s" % teacher["meta"]["wall_time_s"]],
    ["3. 从零 + 蒸馏", "python distill_lm.py --mode all", "成功",
     "%.1f s" % allr["meta"]["wall_time_s"]],
    ["4. 消融实验", "python distill_lm.py --mode ablate", "成功",
     "%.1f s" % ab["meta"]["wall_time_s"]],
    ["5. 拓展 A：FitNet", "python distill_lm.py --mode fitnet --feat 0.1", "成功",
     "%.1f s" % fit["meta"]["wall_time_s"]],
    ["6. 拓展 C：自蒸馏", "python distill_lm.py --mode selfkd", "成功",
     "%.1f s" % selfkd["meta"]["wall_time_s"]],
    ["7. 拓展 D：动态量化", "python distill_lm.py --mode quant", "成功",
     "%.1f s" % quant["meta"]["wall_time_s"]],
    ["8. 拓展 E：教师规模", "python distill_lm.py --mode scale", "成功",
     "%.1f s" % scale["meta"]["wall_time_s"]],
]
while len(t2.rows) < len(cmd_rows) + 1:
    t2.add_row()
for i, row in enumerate(cmd_rows, start=1):
    set_cell(t2.rows[i].cells[0], row[0], size=9.5, align=LEFT)
    set_cell(t2.rows[i].cells[1], row[1], size=8.5, align=LEFT, font="Consolas")
    set_cell(t2.rows[i].cells[2], row[2], size=9.5, align=CENTER)
    set_cell(t2.rows[i].cells[3], row[3], size=9.5, align=CENTER)
set_col_widths(t2, [2.5, 8.0, 2.8, 2.5])

p_t2 = new_para_after_table(
    t2,
    "环境变量：PYTHONUTF8=1、PYTHONIOENCODING=utf-8、OMP_NUM_THREADS=8；所有命令在 "
    "Windows 11 终端执行，日志见 runs_distill/logs/。B（热力图）直接复用消融数据，"
    "不单独训练，因此表 2 没有额外命令行。",
    size=10.5, after=4)
p_fair = new_para_after(
    p_t2,
    "公平对照：两个学生都用 seed+7 初始化，数据采样器都用 seed+1，batch/block/lr/steps 完全一致；"
    "教师冻结并 eval；唯一差别是 KD 组多一项 KL。消融 16 组也用同一初始化与同一批缓存教师 logits。",
    size=10.5, after=4)
code_anchor = new_para_after(
    p_fair, "关键实现（KL 部分）：", size=10.5, bold=True, color=INK, after=2)
code_anchor.paragraph_format.keep_with_next = True
code_p = add_code_block(code_anchor, [
    "V = logits.size(-1)",
    "s_lp = F.log_softmax(logits.reshape(-1, V) / T, dim=-1)",
    "t_p  = F.softmax(t_logits.reshape(-1, V) / T, dim=-1)",
    'kd   = F.kl_div(s_lp, t_p, reduction="batchmean") * (T * T)',
    "loss = (1 - alpha) * ce + alpha * kd",
])
new_para_after(
    code_p,
    "复现说明：首次按 PDF 排版直接抄写 build_corpus 会得到 vocab=323、train_chars=55,456、"
    "val_chars=5,956；按指南实测值 322/49,457/5,357 还原为“行内不加空格、只在合成诗句后补一个"
    "换行”后完全一致，教师参数量 737,280、学生 147,456、压缩比 5.0×。",
    size=10.5, after=4)

# ---------- 五、参数配置 ----------
param_rows = [
    ["n_layer", "2", "2"],
    ["n_head", "4", "4"],
    ["n_embd", "160", "64"],
    ["block_size", "96", "96"],
    ["参数量", "0.737 M（737,280）", "0.147 M（147,456）"],
    ["压缩比", "—", "5.0×"],
]
for i, row in enumerate(param_rows, start=1):
    for j, v in enumerate(row):
        set_cell(t3.rows[i].cells[j], v, size=10.0,
                 align=LEFT if j == 0 else CENTER)

hyper_rows = [
    ["温度 T", "4", "默认 4"],
    ["权重 α", "0.5", "默认 0.5"],
    ["学习率", "3e-3", "默认 3e-3"],
    ["batch_size", "24", "默认 24"],
    ["教师训练步数", "200", "默认 200"],
    ["学生训练步数", "120", "默认 120"],
    ["随机种子", "0", "默认 0"],
    ["特征蒸馏权重", "0（主实验）/ 0.1（A）", "0 表示关闭"],
]
for i, row in enumerate(hyper_rows, start=1):
    for j, v in enumerate(row):
        set_cell(t4.rows[i].cells[j], v, size=10.0,
                 align=LEFT if j == 2 else CENTER)

p_t4 = new_para_after_table(
    t4,
    "优化器 AdamW，weight_decay=0.01，梯度裁剪 1.0，dropout=0.0；8 线程；教师全程 eval/freeze。",
    size=10.5, after=4)
new_para_after(
    p_t4,
    "参数量手算（忽略 LayerNorm/偏置）：教师 322×160 + 96×160 + 2×12×160² + 322×160 "
    "= 51,520 + 15,360 + 614,400 + 51,520 = 732,800；实测 737,280，差 4,480（0.61%），"
    "来自 5 个 LayerNorm 的 1,600 个参数和每层 1,440 个偏置（2 层共 2,880）。学生 "
    "322×64 + 96×64 + 2×12×64² + 322×64 = 20,608 + 6,144 + 98,304 + 20,608 = 145,664；"
    "实测 147,456，差 1,792（1.23%），来自 5 个 LayerNorm 的 640 个参数和每层 576 个偏置"
    "（2 层共 1,152）。压缩比 737,280 / 147,456 = 5.0×。",
    size=10.5, after=4)

# ---------- 六、实验数据 ----------
p6 = find_par(doc, "六、实验数据记录")
new_para_after(
    p6,
    "数据：vocab=322；训练集 49,457 字符、留出集 5,357 字符；block=96、batch=24；"
    "留出集与训练集同一文法、不同随机种子。评估用 20 个 batch 的 CE 均值，一致率用 10 个 "
    "batch 的 top-1 一致率。",
    size=10.5, after=4)

model_rows = [
    ["教师 Teacher", "0.737 M", "200", f1(T["time_s"]) + " s",
     f4(T["val_loss"]), f2(T["ppl"]), "—"],
    ["学生·从零训练", "0.147 M", "120", f1(S["time_s"]) + " s",
     f4(S["val_loss"]), f2(S["ppl"]), f3(S["agree"])],
    ["学生·蒸馏训练", "0.147 M", "120", f1(K["time_s"]) + " s",
     f4(K["val_loss"]), f2(K["ppl"]), f3(K["agree"])],
]
for i, row in enumerate(model_rows, start=1):
    for j, v in enumerate(row):
        set_cell(t5.rows[i].cells[j], v, size=9.0,
                 align=LEFT if j == 0 else CENTER)

# 表 6：4x4
p_t7cap = find_par(doc, "【表 7")
p_t7cap.paragraph_format.keep_with_next = True
p_t7cap.paragraph_format.page_break_before = True
for i, tv in enumerate([1, 2, 4, 8], start=1):
    set_cell(t6.rows[i].cells[0], "T = %d" % tv, size=10.0, align=CENTER)
    for j, av in enumerate([0.3, 0.5, 0.7, 0.9], start=1):
        r = next(x for x in ab["ablation"] if x["T"] == tv and abs(x["alpha"] - av) < 1e-9)
        is_best = (tv == BEST["T"] and abs(av - BEST["alpha"]) < 1e-9)
        set_cell(t6.rows[i].cells[j], f4(r["val_loss"]), size=10.0,
                 bold=is_best, align=CENTER)
new_para_after_table(
    t6,
    "注：每组 80 步、单种子；加粗为 16 格最优（T=8、α=0.5）；绝对数值与 120 步主实验"
    "不可直接比较，重点看相对趋势。",
    size=9.5, after=4)

# 表 7：生成样例
samples = allr["samples"]
set_cell(t7.rows[0].cells[1], "生成结果（60 token）", size=10.5,
         bold=True, align=CENTER)
for i, (name, key) in enumerate(
        [("教师", "teacher"), ("学生·从零训练", "scratch"), ("学生·蒸馏训练", "kd")],
        start=1):
    set_cell(t7.rows[i].cells[0], name, size=9.0, align=LEFT)
    set_cell(t7.rows[i].cells[1], samples[key], size=8.5, align=LEFT, line=1.0)
new_para_after_table(
    t7,
    "生成条件：prompt=“月”，60 token，temperature=0.9，top_k=20，三组固定采样种子 2024；"
    "表格按原样保留 60 token 的截断。",
    size=9.5, after=4)

# 7.1 - 7.4
p = find_par(doc, "（粘贴 runs_distill/curves.png")
set_par(p,
        "图 1(a) 中教师前 25 步下降最快，约 50 步后进入 0.8–1.2 的平台，并伴随周期性尖峰"
        "（小 batch + AdamW 的正常波动）；两个学生前 40 步几乎重合，40 步后蒸馏学生略低，"
        "120 步附近都进入平台。图 1(b) 的留出集更清楚：教师 0.9986，从零 1.5060，蒸馏 1.4437。"
        "需要强调：KD 组的训练损失含 T²·KL，和 scratch 的纯 CE 不是同一尺度，不能直接比绝对值；"
        "7.2 的留出集 CE/PPL 才是公平比较。",
        size=10.5, after=4)
new_para_after(p,
               "从下降速度看，教师在同样 120 步之前已明显领先，说明 5× 容量确实带来了更强的拟合能力；"
               "两个学生受容量限制，120 步时仍在欠拟合区间，这也解释了为什么 KD 的收益会在这个区间出现。",
               size=10.5, after=4)

p = find_par(doc, "（对比表 6 中两行学生数据")
set_par(p,
        "同参数量（147,456）、同初始化（seed+7）、同数据顺序（seed+1）、同 120 步、同优化器，"
        "唯一差异是 KD 组多一项 KL。蒸馏把留出集 loss 从 1.5060 降到 1.4437，绝对下降 0.0623，"
        "相对下降 4.14%；PPL 从 4.51 降到 4.24（−6.04%）；与教师 top-1 一致率从 0.619 升到 0.686"
        "（+6.69 个百分点，相对 +10.8%）。按“学生-教师差距”衡量，KD 缩小了 "
        "(1.5060−1.4437)/(1.5060−0.9986)=12.3% 的差距。loss、PPL、一致率三项同向改善，说明学生"
        "不只是被正则“压平”，而是学到了教师判断中的部分结构；但单种子、固定古诗重叠、120 步"
        "欠拟合区间使这一结论仍是初步的，严格区分“信息 vs 正则”需要 Q4 的对照。",
        size=10.5, after=4)
new_para_after(p,
               "另一个容易被忽略的点是耗时：蒸馏组每步多一次教师前向与 KL 计算，训练时间从 2.2 s "
               "增到 3.7 s，约 1.7×；换来的留出集收益是 4.14%。在 0.147 M 这种小模型上，"
               "这是一笔划算但不算巨大的交易；若教师更大、步数更多，KD 的训练成本会继续上升。",
               size=10.5, after=4)

p = find_par(doc, "（最优组合是哪一组")
set_par(p,
        "最优格是 T=8、α=0.5（1.6487），次优 T=8、α=0.7（1.6489）和 T=4、α=0.5（1.6573），"
        "最差 T=8、α=0.9（1.8051）。T=1 的四个格为 1.7241–1.7371，极差仅 %.4f，几乎不随 α 变化："
        "T=1 时软标签接近 one-hot，KL 近似 CE，暗知识很少。T=2 整体偏差，且 α=0.9 已达 1.7965；"
        "T=4/8 在 α=0.5–0.7 最好，说明需要足够平滑的分布才能暴露类间结构。α=0.9 在 T=8 最差，"
        "因为 (1−α)CE 只剩 0.1，硬标签约束几乎消失，而教师本身也不完美（val=0.9986），学生被教师"
        "错误拉走；同时 T² 放大了 KL 梯度，α 越大越明显。T 过大本身不是致命问题（T=8、α=0.5 仍最好），"
        "关键是 T 与 α 的匹配：温度负责“把结构摊开”，α 负责“别把硬标签丢掉”。" % T1_SPREAD,
        size=10.5, after=4)
new_para_after(p,
               "从梯度看，∂L/∂z_s = (1−α)(p_s−y) + α·T·(p_s^T−p_t^T)。T=1 时第二项近似普通 CE，"
               "α 几乎不改变结果；T 增大时 p_s^T−p_t^T 变得更平滑、类间差异更可见，但 α 接近 1 会让"
               "第一项消失，教师误差被完整继承。本实验的 16 格正好把这个二维边界画了出来。",
               size=10.5, after=4)

p = find_par(doc, "（对比表 8 中三段生成文本")
set_par(p,
        "三段文本都只生成了 60 token，且是单次采样，不能当指标，只能看局部文法。教师最稳："
        "“月了一夜看，此意难平。诗人梦见道：‘秋草可惜。’泪湿衣襟。……”基本沿着"
        "“主语+地点+动词+宾语+情绪”的模板走，引号/句号基本闭合；开头“月了一夜看”略怪，"
        "但仍在语料文法内。从零学生明显更碎：“月，长亭送去‘远帆可惜。牧童在舟中惆怅。’"
        "欣然无语还休。……”引号开合错位、模板混搭（“欣然/无语/还休”），但局部词组合法。"
        "蒸馏学生前半段最像教师：“月了一夜看，此意难平。诗人在窗前青山了一夜看，默然无语。……”"
        "沿用了教师的开头和合法模板；后半段出现“山了一笑而别。山了一笑而别”的重复/崩坏，"
        "说明 0.147 M 的容量仍不足以维持 60 token 的一致性。总体：蒸馏文本比从零更接近教师，"
        "尤其在开头 20–30 token；但两者都会在长序列上退化，教师也不是完美教师。",
        size=10.5, after=4)
new_para_after(p,
               "这段观察与 7.2 的定量结果一致：KD 把学生拉向教师的局部判断，但没有改变学生"
               "“长序列会漂”的根本容量限制。生成样例只用于定性佐证，不作为主要评价指标。",
               size=10.5, after=4)

# ---------- 图 1 / 图 2 ----------
insert_image_cell(t8.rows[0].cells[0], os.path.join(OUT, "curves.png"), 15.0)
insert_image_cell(t9.rows[0].cells[0], os.path.join(OUT, "ablation_heatmap.png"), 11.5)

p_fig1 = find_par(doc, "图 1　教师 / 从零学生 / 蒸馏学生的训练损失曲线")
set_par(p_fig1, "图 1　教师 / 从零学生 / 蒸馏学生的训练损失与留出集指标",
        size=10.5, bold=True, color=BODY, font=HEAD_FONT, align=CENTER,
        before=3, after=3, line=1.1)
p_fig2 = find_par(doc, "图 2　T × α 消融曲线 / 热力图")
set_par(p_fig2, "图 2　T × α 消融热力图（留出集 loss）",
        size=10.5, bold=True, color=BODY, font=HEAD_FONT, align=CENTER,
        before=3, after=3, line=1.1)

# ---------- 八、拓展 ----------
p8 = find_par(doc, "八、拓展加分实验")
new_para_after(
    p8,
    "在必做四项之外，本轮完成 A–E 五项；B 直接复用消融数据，不额外训练；F 未做。"
    "所有拓展数据来自独立 JSON，未与主实验混写。",
    size=10.5, after=4)

ext_rows = [
    ["A", "特征蒸馏（FitNet）", "完成",
     "FEAT=0.1：val=1.4191，较 KD 1.4437 再降 0.0247（1.7%），较 scratch 降 5.8%；agree=0.681",
     "+5"],
    ["B", "温度/权重热力图", "完成",
     "16 格热力图；最优 T=8、α=0.5（1.6487），最差 T=8、α=0.9（1.8051）", "+3"],
    ["C", "自蒸馏", "完成",
     "同构 200 步教师 val=1.2513；自蒸馏学生 1.3935，较 scratch 降 7.5%，较主 KD 再降 3.5%",
     "+4"],
    ["D", "动态量化导出", "完成",
     "0.6425→0.3087 MB（2.08×）；2.63→4.01 ms；val 1.4437→1.4431；top-1 一致率 0.982", "+5"],
    ["E", "教师规模扫描", "完成",
     "C=96/160/256 教师 val=1.1263/0.9986/0.9381；KD 收益 0.0492/0.0623/0.0450", "+4"],
    ["F", "换成真实语料", "未完成",
     "未接入外部真实语料；为保持零网络、可复现，本轮聚焦 A–E", "0"],
]
for i, row in enumerate(ext_rows, start=1):
    for j, v in enumerate(row):
        set_cell(t10.rows[i].cells[j], v,
                 size=8.5 if j == 3 else 9.0,
                 align=LEFT if j in (1, 3) else CENTER)
set_col_widths(t10, [1.2, 3.0, 2.2, 7.4, 1.6])
add_caption_before_table(t10, "表 9　拓展加分实验汇总")
new_para_after_table(
    t10,
    "A–E 合计 21 分，按评分上限计 15 分；F 不计分。表中的收益均为同一测试口径（留出集 CE）下的"
    "绝对差或相对差，量化延迟为本机 8 线程、batch=24、block=96 的中位数。",
    size=9.5, after=4)

# 8.1 - 8.6 插在“九、问题与解决”之前
p9 = find_par(doc, "九、问题与解决")

add_heading(p9, "8.1　A：FitNet 特征蒸馏")
new_para_before(
    p9,
    "在 KD 损失上再加 0.1×MSE(proj(h_s), h_t)，proj 为 64→160 线性层，仅训练期使用。结果 "
    "val=1.4191，较纯 KD 的 1.4437 再降 0.0247（1.71%），较 scratch 降 0.0869（5.77%）；"
    "agree=0.681，与纯 KD 的 0.686 基本持平。说明中间层特征提供了额外的监督信号，但收益是"
    "“锦上添花”，没有改变学生-教师一致率；投影在推理时丢弃，学生参数量仍为 0.147 M。"
    "0.1 的权重未做扫描，不能断言最优。",
    size=10.5, after=4)

add_heading(p9, "8.2　B：T×α 热力图")
new_para_before(
    p9,
    "图 2 即 16 格热力图，最优/最差与 7.3 一致；B 的价值在于把“T 太小无暗知识、T 太大/α 太大"
    "丢硬标签”的二维边界可视化。该图不额外训练，直接由 results_ablate.json 生成，和表 7 "
    "互为对照。",
    size=10.5, after=4)

add_heading(p9, "8.3　C：自蒸馏")
new_para_before(
    p9,
    "教师换成同结构、训练 200 步的学生（val=1.2513，优于 120 步 scratch 的 1.5060）；再用它蒸"
    "一个 120 步新学生，得到 1.3935，较 scratch 降 0.1125（7.47%），较主教师 KD 的 1.4437 再降 "
    "0.0502（3.48%）。说明在本实验的欠拟合区间，同构教师“多训 80 步”仍能提供有用的软标签；"
    "但 200 步尚未进入明显过拟合，不能推断更长训练仍有效。注意 0.764 的一致率是相对自教师，"
    "不是相对 0.737 M 主教师，不能与主 KD 的 0.686 直接横比。",
    size=10.5, after=4)

add_heading(p9, "8.4　D：动态量化")
new_para_before(
    p9,
    "对蒸馏学生做 quantize_dynamic(..., {nn.Linear}, qint8)：state_dict 0.6425 MB→0.3087 MB"
    "（2.08×），未到 4× 是因为 embedding/LayerNorm 仍是 fp32；单次前向中位延迟 2.63→4.01 ms"
    "（0.65×，反而慢 1.53×），这是小模型动态量化的典型开销；val 1.4437→1.4431（−0.0006，"
    "噪声级），top-1 一致率 0.982。结论：精度几乎无损、体积减半，但本机没有速度收益；生产环境"
    "应改用静态量化/QAT 或 torchao，并配合更大 batch。",
    size=10.5, after=4)

add_heading(p9, "8.5　E：教师规模扫描")
new_para_before(
    p9,
    "固定学生 0.147 M、120 步、T=4、α=0.5，只改教师宽度 C；C=160 复用主教师，C=96/256 "
    "重新训 200 步。",
    size=10.5, after=4)

scale_rows = [
    ["教师宽度 C", "教师参数量", "教师 val", "从零学生 val", "蒸馏学生 val", "绝对收益"],
]
for r in SCALE_ROWS:
    scale_rows.append([
        "C=%d" % r["C"],
        "%.3f M" % (r["teacher_params"] / 1e6),
        f4(r["teacher_val_loss"]),
        f4(r["scratch_val_loss"]),
        f4(r["kd_val_loss"]),
        "%s（%s）" % (f4(r["gain_abs"]), pct(r["gain_pct"])),
    ])
scale_tbl = add_table_before_par(p9, scale_rows, [2.0, 2.6, 2.9, 2.9, 2.9, 2.5])
add_caption_before_table(scale_tbl, "表 10　教师规模扫描（学生 120 步，T=4、α=0.5）")

fig3 = add_figure_before(p9, os.path.join(OUT, "teacher_scale.png"), 14.5)
add_caption_after(fig3, "图 3　教师规模扫描：教师越强不等于蒸馏收益越大")

p_scale_analysis = new_para_before(
    p9,
    "教师从 0.295 M→0.737 M→1.769 M，val 从 1.1263→0.9986→0.9381 单调变好；但 KD 收益先升"
    "后降：0.0492→0.0623→0.0450。C=256 教师最强，学生却不如 C=160，且与教师一致率只有 0.620"
    "（C=160 为 0.686）。这说明教师强度是必要条件但不是充分条件：0.147 M 学生有容量瓶颈，"
    "过强的教师可能给出更尖、更“教师特化”的分布，学生更难模仿；单种子/120 步的噪声也会放大"
    "0.017 的差距。结论应表述为“在本设置下 C=160 左右最匹配”，而不是“教师越大越好”。",
    size=10.5, after=4)
p_scale_analysis.paragraph_format.keep_together = True

add_heading(p9, "8.6　F：真实语料（未完成）")
new_para_before(
    p9,
    "本轮未接入作业三的唐诗或自备语料，原因是保持零网络、零外部依赖和完全可复现；因此 F 不计分。"
    "若后续要做，建议用同一字符级 tokenizer 重新统计 vocab，并保持 train/val 语料来源分离，"
    "避免固定古诗同时出现在两边。",
    size=10.5, after=4)

# ---------- 九、问题与解决 ----------
new_para_after(
    find_par(doc, "九、问题与解决"),
    "本次实验没有出现阻断性错误；以下 3 个问题分别影响复现、量化和环境一致性，均已处理。",
    size=10.5, after=4)
issue_rows = [
    ["1",
     "首次复现 build_corpus 得到 vocab=323、train_chars=55,456、val_chars=5,956，"
     "与指南 322/49,457/5,357 不一致",
     "PDF 排版把行内空格和逐行换行显示出来；实际语料应为行内不加空格、只在合成诗句后补一个换行",
     "按指南实测计数还原模板；修正后三项完全一致，教师 737,280、学生 147,456、压缩比 5.0×"],
    ["2",
     "DeprecationWarning: torch.ao.quantization is deprecated ... migrate to torchao；"
     "torch.quantize_per_tensor 也有 UserWarning",
     "PyTorch 2.14 对动态量化旧 API 的弃用提示；实验仍能运行",
     "保留 torch.ao.quantization.quantize_dynamic 完成 D；报告中注明生产环境应迁移到 "
     "torchao/静态量化，不把 warning 当失败"],
    ["3",
     "指南环境为 Python 3.11 / PyTorch 2.15.0+cpu；本机为 Python 3.14.0 / 2.14.0+cu130，"
     "且 cuda_available=True",
     "本机只安装了 3.14 与 CUDA 构建；实验要求纯 CPU",
     "强制所有张量在 CPU、固定 8 线程；实测教师 val=0.9986 与指南一致，说明版本差异未改变结论；"
     "报告中如实记录"],
]
for i, row in enumerate(issue_rows, start=1):
    for j, v in enumerate(row):
        set_cell(t11.rows[i].cells[j], v, size=8.5,
                 align=CENTER if j == 0 else LEFT, line=1.0)
set_col_widths(t11, [1.2, 4.3, 4.6, 5.5])
add_caption_before_table(t11, "表 11　问题与解决记录")

# ---------- 十、结论 ----------
p = find_par(doc, "（总结本次实验的完成情况")
set_par(p,
        "本次完成必做四项与 A–E 五项：教师 0.737 M / val 0.9986 / PPL 2.71；学生 0.147 M，"
        "压缩 5.0×；同预算下 scratch 1.5060→KD 1.4437（−4.14%），PPL 4.51→4.24，教师一致率 "
        "0.619→0.686，KD 缩小了 12.3% 的学生-教师差距。",
        size=10.5, after=4)
p_concl = new_para_after(p,
               "消融显示 T=1 几乎无效（1.7241–1.7371），T=4–8 且 α=0.5–0.7 最好（最优 T=8、α=0.5，"
               "1.6487），T=8、α=0.9 最差（1.8051）；温度负责摊开结构，α 负责保留硬标签，两者必须"
               "匹配。拓展中 FitNet 1.4191、自蒸馏 1.3935 都优于纯 KD；int8 体积减半、精度几乎不变"
               "但本机不加速；教师规模收益在 C=160 最好，C=256 反而回落，说明教师强度要与学生容量"
               "匹配。",
               size=10.5, after=4)
new_para_after(p_concl,
               "学到的核心不是“蒸馏一定涨点”，而是：软标签是带结构的正则，T² 是让不同 T 可比较的"
               "梯度缩放，公平对照必须锁死初始化/数据顺序/步数；压缩技术各有分工——蒸馏减参数、"
               "量化减精度、剪枝减结构。局限：单种子、合成语料、固定古诗重叠、120 步欠拟合区间、"
               "消融仅 80 步、量化只测一台机器。改进：3–5 个种子、去掉 val 中固定古诗、接入真实语料、"
               "200+ 步对照、剪枝+QAT+静态量化流水线、更大容量学生。",
               size=10.5, after=4)

# ---------- 十一、思考题 ----------
answers = {
    "1.  蒸馏时学生只学软标签": (
        "答：设 p_s=softmax(z_s)，p_s^T=softmax(z_s/T)，p_t^T=softmax(z_t/T)，则 "
        "∂L/∂z_s = (1−α)(p_s−y) + α·T·(p_s^T−p_t^T)。α=1 时第一项消失，学生只被教师分布牵引："
        "教师哪里错，学生就被拉向哪里；教师本身的系统性误差、类先验偏差会被完整继承。硬标签项"
        "提供无偏的“正确答案”锚点，防止学生在教师不确定/错误的类上漂移，也保留真实类的 margin。"
        "T 很大时软标签接近均匀，KL 梯度虽被 T² 保住量级，但方向退化为很弱的 logit 匹配，硬标签"
        "更是唯一可靠信号。因此 α=1 通常不如 0.5–0.9，尤其教师不完美时。"),
    "2.  KD 损失里为什么必须乘": (
        "答：KL 对 z_s 的梯度含 1/T（softmax(z_s/T) 的导数），而 p_s^T−p_t^T 在 logits 差远小于 T "
        "时也近似按 1/T 缩小，所以未乘 T² 时 KD 梯度约按 1/T² 衰减。T 从 4 改到 8，梯度约变为原来"
        "的 1/4；若想保持有效步长，应把学习率乘以 4（或把 α 调大），否则蒸馏项几乎不动。乘 T² 后"
        "梯度回到 O(1)，换 T 不必重调 LR，这也是指南强调 T² 的原因。"),
    "3.  本实验的教师只有 0.74 M": (
        "答：0.74 M 绝对规模不算“大模型”，它只是学生的 5× 容量教师；这里的“大”是相对的。教师"
        "规模扫描：C=96/160/256 的教师 val 为 1.1263/0.9986/0.9381，KD 收益为 0.0492/0.0623/0.0450。"
        "收益随教师变强先升后降，C=256 教师最强但学生 1.4610 不如 C=160 的 1.4437，且与教师一致率"
        "降到 0.620。说明蒸馏收益依赖“教师比学生强且匹配学生容量”，不是教师越大越好；教师太弱"
        "（接近学生）时暗知识不足，教师过强/过尖时 0.147 M 学生难以模仿。"),
    "4.  在同样的参数量下": (
        "答：设计三组对照，把“信息”和“正则”拆开：①随机教师——保留同样的温度/熵，但把教师 logits "
        "在类维度随机打乱（或用在随机标签上训练的教师）；若 KD 收益消失，说明收益来自正确的类间"
        "结构（信息），若仍在则更像正则。②标签平滑/熵正则基线——让 scratch 学生的损失含与软标签"
        "同等熵的均匀标签平滑，若它也能带来同等收益，则 KD 的增益可被“正则”解释。③一致性检验——"
        "信息转移应同时提高学生-教师 top-1 一致率；纯正则未必。本实验 KD 的 loss、PPL、agree 同时"
        "改善（0.619→0.686），更像信息，但还不足以排除正则，需上述对照才能定论。"),
    "5.  如果把温度 T 设为 100": (
        "答：T=100 时 p_i^T≈1/322，所有类几乎均匀，软标签里的“光/色/夜”结构被压到 O(1/T) 量级，"
        "暗知识基本消失。T² 缩放会让梯度量级不至于消失，但方向退化为对教师 logits 的线性拟合，"
        "等价于很弱的 MSE 正则；学生主要仍靠硬标签，蒸馏项既不能提供有效结构，还可能引入教师噪声。"
        "因此 T=100 基本不起作用，甚至略差于纯 scratch；数值上 softmax 仍稳定，但“信息”已经没有了。"),
    "6.  蒸馏、量化、剪枝都能压缩模型": (
        "答：蒸馏压缩的是参数/架构（教师→小模型学生的参数量与宽度）；量化压缩数值精度（fp32→int8/fp16）；"
        "剪枝压缩结构（删权重/头/层）。三者可叠加，顺序一般是：先用蒸馏得到小而密的 student（本实验 "
        "5×），再剪枝 30–50% 并 fine-tune 恢复，再做 QAT/静态 int8 量化，最后导出并测 accuracy/latency/size。"
        "D 的 dynamic int8 已把体积减半、精度几乎不变，但本机不加速；若要与剪枝叠加，建议剪枝后做"
        "量化感知微调，避免“先量化再剪枝”破坏量化参数。"),
}
last_answer = None
for q_prefix, ans in answers.items():
    q = find_par(doc, q_prefix)
    q.paragraph_format.keep_with_next = True
    last_answer = new_para_after(q, ans, size=10.5, after=6)

# 附录：填满最后一页，同时给出复现入口
appendix_title = new_para_after(
    last_answer, "附：复现材料清单", size=12, bold=True, color=INK,
    font=HEAD_FONT, align=LEFT, before=10, after=4, line=1.15)
appendix_items = [
    "代码：distill_lm.py（数据/模型/训练/消融/拓展）、make_figures.py（图表）、"
    "build_report.py（报告生成）、verify_report.py（结构校验）。",
    "数据：runs_distill/results_*.json、summary.txt；权重：teacher.pt、student_*.pt；"
    "日志：runs_distill/logs/*.log。",
    "图表：curves.png、ablation_heatmap.png、teacher_scale.png；报告："
    "2025310291_杨锐_实验作业八.docx（同目录另有 PDF 版）。",
    "复现顺序：teacher --retrain → all → ablate → fitnet → selfkd → quant → scale；"
    "本机 8 线程 CPU 全程约 1.5–2 分钟（不含报告生成）。",
]
a = appendix_title
for item in appendix_items:
    a = new_para_after(a, "· " + item, size=9.5, after=3)

ref_title = new_para_after(
    a, "参考文献", size=12, bold=True, color=INK, font=HEAD_FONT,
    align=LEFT, before=10, after=3, line=1.15)
refs = [
    "[1] Hinton G., Vinyals O., Dean J. Distilling the Knowledge in a Neural Network. "
    "arXiv:1503.02531, 2015.",
    "[2] Romero A., Ballas N., Kahou S. E., et al. FitNets: Hints for Thin Deep Nets. "
    "ICLR 2015.",
    "[3] 教材第 15 章《模型量化与压缩技术》；第 5 章《Transformer 模型》。",
    "[4] PyTorch Documentation. Quantization / Dynamic Quantization. "
    "https://pytorch.org/docs/stable/quantization.html",
]
r = ref_title
for item in refs:
    r = new_para_after(r, item, size=9.0, after=2)

# ---------- 表格格式 & 页脚 ----------
for table in doc.tables:
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    no_split_rows(table, header=(table is not t8 and table is not t9))

add_footer(doc)
cp = doc.core_properties
cp.title = "自制语言模型的知识蒸馏（纯 CPU）实验报告"
cp.author = "杨锐"
cp.subject = "实验八：知识蒸馏 / 模型压缩"
cp.comments = "数据来自 runs_distill 下的真实运行 JSON。"

# 保存
doc.save(DST)
print("saved", DST)
