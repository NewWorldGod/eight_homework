# -*- coding: utf-8 -*-
"""校验生成的报告：结构、占位符、图表、关键数字。"""

import json
import os
import sys

from docx import Document
from docx.oxml.ns import qn

BASE = os.path.dirname(os.path.abspath(__file__))
DOCX = os.path.join(BASE, "2025310291_杨锐_实验作业八.docx")
PDF = os.path.join(BASE, "2025310291_杨锐_实验作业八.pdf")
OUT = os.path.join(BASE, "runs_distill")


def load(name):
    with open(os.path.join(OUT, name), "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    assert os.path.exists(DOCX), DOCX
    doc = Document(DOCX)
    texts = [p.text for p in doc.paragraphs]
    all_text = "\n".join(texts)
    errors = []

    # 1. 结构
    for h in ["一、实验目的", "二、实验环境", "三、实验原理简述", "四、实验步骤与命令记录",
              "五、参数配置记录", "六、实验数据记录", "七、结果与分析",
              "八、拓展加分实验", "九、问题与解决", "十、结论", "十一、思考题解答"]:
        if h not in all_text:
            errors.append("缺少章节：" + h)
    if len(doc.tables) != 13:
        errors.append("表格数不是 13：%d" % len(doc.tables))
    if len(doc.inline_shapes) != 3:
        errors.append("图片数不是 3：%d" % len(doc.inline_shapes))

    # 2. 占位符
    for hint in ["请用自己的语言", "简述知识蒸馏", "粘贴 runs_distill", "对比表 6",
                 "最优组合是哪一组", "对比表 8", "总结本次实验", "此处粘贴", "（请"]:
        if hint in all_text:
            errors.append("残留占位符：" + hint)

    # 3. 思考题答案
    for q in ["1.  蒸馏时学生只学软标签", "2.  KD 损失里为什么必须乘",
              "3.  本实验的教师只有 0.74 M", "4.  在同样的参数量下",
              "5.  如果把温度 T 设为 100", "6.  蒸馏、量化、剪枝都能压缩模型"]:
        if q not in all_text:
            errors.append("缺少问题：" + q)
        if "答：" not in all_text:
            errors.append("缺少答案标记")

    # 4. 关键数字（主实验）
    tea = load("results_teacher.json")["teacher"]
    allr = load("results_all.json")
    ab = load("results_ablate.json")
    fit = load("results_fitnet.json")["fitnet"]
    selfkd = load("results_selfkd.json")
    quant = load("results_quant.json")["quant"]
    scale = load("results_scale.json")["scale"]

    expected = [
        "%.4f" % tea["val_loss"],
        "%.4f" % allr["scratch"]["val_loss"],
        "%.4f" % allr["kd"]["val_loss"],
        "%.4f" % ab["best"]["val_loss"],
        "%.4f" % ab["worst"]["val_loss"],
        "%.4f" % fit["val_loss"],
        "%.4f" % selfkd["selfkd"]["val_loss"],
        "%.4f" % quant["fp32_size_mb"],
        "%.4f" % quant["int8_size_mb"],
    ]
    for x in expected:
        if x not in all_text:
            errors.append("报告缺少数字：" + x)

    # 5. 表 6 16 格
    t6 = doc.tables[6]
    for r in ab["ablation"]:
        row = {1: 1, 2: 2, 4: 3, 8: 4}[r["T"]]
        col = {0.3: 1, 0.5: 2, 0.7: 3, 0.9: 4}[r["alpha"]]
        if t6.rows[row].cells[col].text.strip() != "%.4f" % r["val_loss"]:
            errors.append("表 6 数值不一致 T=%s a=%s" % (r["T"], r["alpha"]))

    # 6. 教师规模表
    if len(scale) != 3:
        errors.append("教师规模不是 3 组")

    # 7. 空单元格（图片单元格除外）
    for ti, table in enumerate(doc.tables):
        for ri, row in enumerate(table.rows):
            for ci, cell in enumerate(row.cells):
                has_drawing = bool(cell._tc.findall(".//" + qn("w:drawing")))
                if not cell.text.strip() and not has_drawing:
                    errors.append("空单元格 T%d R%d C%d" % (ti, ri, ci))

    # 8. PDF
    if os.path.exists(PDF):
        try:
            import pymupdf
            pdf = pymupdf.open(PDF)
            if len(pdf) < 8:
                errors.append("PDF 页数过少：%d" % len(pdf))
        except Exception as e:
            errors.append("PDF 检查失败：%s" % e)

    if errors:
        print("FAILED")
        for e in errors:
            print(" -", e)
        sys.exit(1)
    print("OK")
    print("paragraphs:", len(doc.paragraphs), "tables:", len(doc.tables),
          "images:", len(doc.inline_shapes))
    print("pdf_pages:", len(pymupdf.open(PDF)) if os.path.exists(PDF) else "n/a")


if __name__ == "__main__":
    main()
