# 实验八：自制语言模型的知识蒸馏（纯 CPU）

本目录包含完整实验代码、真实运行结果、图表和实验报告。

## 结果摘要

- 教师：0.737 M 参数，200 步，留出集 loss **0.9986**，PPL **2.71**。
- 学生：0.147 M 参数，压缩 **5.0×**；同初始化/同数据顺序/同步数下：
  - 从零训练：loss **1.5060**，PPL **4.51**，与教师一致率 **0.619**；
  - 蒸馏训练：loss **1.4437**，PPL **4.24**，与教师一致率 **0.686**；
  - 相对下降 **4.14%**，缩小学生-教师差距 **12.3%**。
- T×α 消融 16 格：最优 **T=8、α=0.5（1.6487）**；最差 **T=8、α=0.9（1.8051）**；T=1 四格几乎不变。
- 拓展 A–E：
  - FitNet（0.1）：**1.4191**；
  - 自蒸馏：同构 200 步教师 **1.2513**，学生 **1.3935**；
  - 动态 int8：**0.6425→0.3087 MB（2.08×）**，2.63→4.01 ms，loss 1.4437→1.4431，top-1 一致率 0.982；
  - 教师规模 C=96/160/256：教师 val 1.1263/0.9986/0.9381，KD 收益 0.0492/0.0623/0.0450（C=160 最匹配）。

## 文件

| 文件 | 说明 |
|---|---|
| `2025310291_杨锐_实验作业八.docx` | 最终实验报告（Word） |
| `2025310291_杨锐_实验作业八.pdf` | 最终实验报告（PDF） |
| `distill_lm.py` | 数据/模型/训练/消融/A–E 拓展，单文件 CLI |
| `make_figures.py` | 从 JSON 生成 `curves.png`、`ablation_heatmap.png`、`teacher_scale.png` |
| `build_report.py` | 读取 JSON，填写模板并导出 DOCX |
| `verify_report.py` | 结构、占位符、图表、关键数字校验 |
| `runs_distill/` | 全部 JSON、checkpoint、图、日志 |
| `runs_distill/results_*.json` | 每个阶段的真实指标 |
| `runs_distill/summary.txt` | 关键数字汇总 |

## 环境

- Windows 11，Python 3.14.0，PyTorch 2.14.0+cu130（**只跑 CPU**），matplotlib 3.10.9。
- AMD Ryzen 9 8945HX，16 核 / 32 线程；实验固定 8 线程。
- 无网络依赖；语料由 `build_corpus()` 现场生成。

## 复现命令

```powershell
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$env:OMP_NUM_THREADS='8'

python -X utf8 distill_lm.py --mode quick
python -X utf8 distill_lm.py --mode teacher --retrain
python -X utf8 distill_lm.py --mode all
python -X utf8 distill_lm.py --mode ablate

python -X utf8 distill_lm.py --mode fitnet --feat 0.1
python -X utf8 distill_lm.py --mode selfkd
python -X utf8 distill_lm.py --mode quant
python -X utf8 distill_lm.py --mode scale

python -X utf8 make_figures.py
python -X utf8 build_report.py
python -X utf8 verify_report.py
```

说明：

- `--mode quick` 仅用于环境自检，结果不写入报告。
- 教师权重缓存在 `runs_distill/teacher.pt`；除 `teacher --retrain` 外，其他模式默认复用。
- 所有随机种子固定为 0（学生初始化 seed+7、数据采样器 seed+1）；CPU 8 线程。
- 本机训练远快于指南的 12 核参考值，报告中已注明“仅作本机墙钟记录”。
