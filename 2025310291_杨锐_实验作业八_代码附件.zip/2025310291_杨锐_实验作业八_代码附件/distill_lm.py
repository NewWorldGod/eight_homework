# -*- coding: utf-8 -*-
"""
实验八：自制语言模型的知识蒸馏（纯 CPU）
单文件实现：合成语料 -> 字符级 GPT -> 教师训练 -> 从零学生 / 蒸馏学生
-> T x alpha 消融 -> FitNet / 自蒸馏 / 动态量化 / 教师规模扫描。

常用命令：
  python distill_lm.py --mode quick
  python distill_lm.py --mode teacher --retrain
  python distill_lm.py --mode all
  python distill_lm.py --mode ablate
  python distill_lm.py --mode fitnet --feat 0.1
  python distill_lm.py --mode selfkd
  python distill_lm.py --mode quant
  python distill_lm.py --mode scale
"""

import argparse
import json
import math
import os
import platform
import random
import sys
import time
from datetime import datetime

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(BASE_DIR, "runs_distill")
DEVICE = "cpu"

# ============================================================
# 1. 合成语料：可复现的“仿古诗句”
# ============================================================
SUBJ = ["小明", "小红", "阿远", "书生", "渔夫", "牧童", "旅人", "诗人",
        "少年", "故人", "归客", "山僧", "孤客", "游子"]
PLACE = ["江边", "山寺", "长亭", "渡口", "竹林", "荒村", "城楼", "野渡",
         "溪桥", "松间", "篱下", "窗前", "陌上", "舟中"]
VERB = ["望见", "听见", "想起", "送去", "寻到", "梦见", "独对", "遥看",
        "静听", "又逢", "恰遇", "空忆"]
OBJ = ["明月", "落花", "孤舟", "归雁", "残灯", "细雨", "青山", "晚钟",
       "白雪", "寒江", "疏星", "暮云", "秋草", "远帆"]
MOOD = ["心中惆怅", "不觉天明", "欣然归去", "泪湿衣襟", "长叹一声",
        "默然无语", "忽忆旧游", "欲语还休", "此意难平", "一笑而别"]
POEMS = [
    "床前明月光，疑是地上霜。举头望明月，低头思故乡。",
    "春眠不觉晓，处处闻啼鸟。夜来风雨声，花落知多少。",
    "白日依山尽，黄河入海流。欲穷千里目，更上一层楼。",
    "千山鸟飞绝，万径人踪灭。孤舟蓑笠翁，独钓寒江雪。",
    "空山不见人，但闻人语响。返景入深林，复照青苔上。",
    "红豆生南国，春来发几枝。愿君多采撷，此物最相思。",
    "独坐幽篁里，弹琴复长啸。深林人不知，明月来相照。",
    "月落乌啼霜满天，江枫渔火对愁眠。姑苏城外寒山寺，夜半钟声到客船。",
    "两个黄鹂鸣翠柳，一行白鹭上青天。窗含西岭千秋雪，门泊东吴万里船。",
    "朝辞白帝彩云间，千里江陵一日还。两岸猿声啼不住，轻舟已过万重山。",
    "日照香炉生紫烟，遥看瀑布挂前川。飞流直下三千尺，疑是银河落九天。",
    "渭城朝雨浥轻尘，客舍青青柳色新。劝君更尽一杯酒，西出阳关无故人。",
    "寒雨连江夜入吴，平明送客楚山孤。洛阳亲友如相问，一片冰心在玉壶。",
    "独在异乡为异客，每逢佳节倍思亲。遥知兄弟登高处，遍插茱萸少一人。",
    "清明时节雨纷纷，路上行人欲断魂。借问酒家何处有，牧童遥指杏花村。",
    "朱雀桥边野草花，乌衣巷口夕阳斜。旧时王谢堂前燕，飞入寻常百姓家。",
]


def build_corpus(n_lines=3000, seed=0):
    """固定种子生成训练语料；留出集换种子，检验泛化。"""
    rng = random.Random(seed)
    out = []
    for i in range(n_lines):
        s = rng.choice(SUBJ)
        p = rng.choice(PLACE)
        v = rng.choice(VERB)
        o = rng.choice(OBJ)
        m = rng.choice(MOOD)
        if i % 3 == 0:
            out.append("%s%s%s%s，%s。" % (s, p, v, o, m))
        elif i % 3 == 1:
            out.append("%s在%s%s了一夜%s，%s。" % (
                s, p, o, rng.choice(["看", "听", "守", "忆"]), m))
        else:
            out.append("%s%s道：“%s%s。”%s。" % (
                s, v, o, rng.choice(["正好", "可怜", "可惜", "依旧"]), m))
    # 指南实测 train_chars=49457 / val_chars=5357 / vocab=322：
    # 语料行内不加空格，也不逐行换行，只在合成诗句后补一个换行。
    out.append("\n")
    out.extend(POEMS)
    return "".join(out)


# ============================================================
# 2. 字符级分词
# ============================================================
class Tokenizer:
    def __init__(self, text):
        chars = sorted(set(text))
        self.stoi = {c: i for i, c in enumerate(chars)}
        self.itos = chars
        self.vocab_size = len(chars)

    def encode(self, s):
        return [self.stoi[c] for c in s if c in self.stoi]

    def decode(self, ids):
        return "".join(self.itos[i] for i in ids)


# ============================================================
# 3. 最小 GPT（Pre-Norm，与指南同构，只改宽度）
# ============================================================
class CausalSelfAttention(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        C = cfg["n_embd"]
        assert C % cfg["n_head"] == 0
        self.n_head = cfg["n_head"]
        self.c_attn = nn.Linear(C, 3 * C)
        self.c_proj = nn.Linear(C, C)
        self.drop = nn.Dropout(cfg["dropout"])
        self.register_buffer(
            "mask",
            torch.tril(torch.ones(cfg["block_size"], cfg["block_size"]))
            .view(1, 1, cfg["block_size"], cfg["block_size"]),
        )

    def forward(self, x):
        B, T, C = x.shape
        q, k, v = self.c_attn(x).split(C, dim=2)
        q = q.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        k = k.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        v = v.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        att = (q @ k.transpose(-2, -1)) / math.sqrt(k.size(-1))
        att = att.masked_fill(self.mask[:, :, :T, :T] == 0, float("-inf"))
        att = self.drop(F.softmax(att, dim=-1))
        y = (att @ v).transpose(1, 2).contiguous().view(B, T, C)
        return self.drop(self.c_proj(y))


class MLP(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        C = cfg["n_embd"]
        self.fc = nn.Linear(C, 4 * C)
        self.proj = nn.Linear(4 * C, C)
        self.drop = nn.Dropout(cfg["dropout"])

    def forward(self, x):
        return self.drop(self.proj(F.gelu(self.fc(x))))


class Block(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.ln1 = nn.LayerNorm(cfg["n_embd"])
        self.attn = CausalSelfAttention(cfg)
        self.ln2 = nn.LayerNorm(cfg["n_embd"])
        self.mlp = MLP(cfg)

    def forward(self, x):
        x = x + self.attn(self.ln1(x))
        return x + self.mlp(self.ln2(x))


class GPT(nn.Module):
    def __init__(self, vocab_size, cfg):
        super().__init__()
        self.cfg = cfg
        self.tok_emb = nn.Embedding(vocab_size, cfg["n_embd"])
        self.pos_emb = nn.Embedding(cfg["block_size"], cfg["n_embd"])
        self.drop = nn.Dropout(cfg["dropout"])
        self.blocks = nn.ModuleList([Block(cfg) for _ in range(cfg["n_layer"])])
        self.ln_f = nn.LayerNorm(cfg["n_embd"])
        self.head = nn.Linear(cfg["n_embd"], vocab_size, bias=False)
        self.apply(self._init)
        self.n_param = sum(p.numel() for p in self.parameters())

    @staticmethod
    def _init(m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, std=0.02)
            if m.bias is not None:
                nn.init.zeros_(m.bias)

    def forward(self, idx, targets=None, need_hidden=False):
        B, T = idx.shape
        pos = torch.arange(T, device=idx.device)
        x = self.drop(self.tok_emb(idx) + self.pos_emb(pos))
        for blk in self.blocks:
            x = blk(x)
        x = self.ln_f(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)),
                                   targets.reshape(-1))
        if need_hidden:
            return logits, loss, x
        return logits, loss

    @torch.no_grad()
    def generate(self, idx, max_new_tokens=100, temperature=1.0, top_k=None):
        self.eval()
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -self.cfg["block_size"]:]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :] / max(temperature, 1e-6)
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float("inf")
            probs = F.softmax(logits, dim=-1)
            idx = torch.cat([idx, torch.multinomial(probs, 1)], dim=1)
        return idx


# ============================================================
# 4. 批采样与评估
# ============================================================
def get_batch(data, bs, block, gen):
    ix = torch.randint(len(data) - block - 1, (bs,), generator=gen)
    x = torch.stack([data[i:i + block] for i in ix])
    y = torch.stack([data[i + 1:i + 1 + block] for i in ix])
    return x, y


@torch.no_grad()
def evaluate(model, data, bs, block, iters=20, seed=1234):
    model.eval()
    gen = torch.Generator().manual_seed(seed)
    tot = 0.0
    for _ in range(iters):
        x, y = get_batch(data, bs, block, gen)
        _, loss = model(x, y)
        tot += loss.item()
    model.train()
    return tot / iters


@torch.no_grad()
def agreement(student, teacher, data, bs, block, iters=10, seed=4321):
    """学生与教师在留出集上的 top-1 一致率。"""
    student.eval()
    teacher.eval()
    gen = torch.Generator().manual_seed(seed)
    hit = tot = 0
    for _ in range(iters):
        x, _ = get_batch(data, bs, block, gen)
        a = student(x)[0].argmax(-1)
        b = teacher(x)[0].argmax(-1)
        hit += (a == b).sum().item()
        tot += b.numel()
    student.train()
    teacher.train()
    return hit / max(tot, 1)


# ============================================================
# 5. 训练：hard label / soft label（KD）
# ============================================================
def train(model, data, iters, bs, block, lr=3e-3, seed=0,
          teacher=None, T=4.0, alpha=0.5, feat_weight=0.0,
          log_every=50, tag=""):
    """
    alpha = 0  -> 纯交叉熵（从零训练对照组）
    alpha > 0  -> L = (1-alpha)*CE + alpha*T^2*KL(教师软标签 || 学生)
    feat_weight -> 额外加最后一层隐状态 MSE（FitNet 式特征蒸馏）
    """
    proj = None
    if teacher is not None and feat_weight > 0:
        proj = nn.Linear(model.cfg["n_embd"], teacher.cfg["n_embd"])
    params = list(model.parameters()) + (list(proj.parameters()) if proj is not None else [])
    opt = torch.optim.AdamW(params, lr=lr, weight_decay=0.01)
    gen = torch.Generator().manual_seed(seed + 1)
    hist = []

    if teacher is not None:
        teacher.eval()
    model.train()
    t0 = time.time()
    for it in range(iters):
        x, y = get_batch(data, bs, block, gen)
        logits = model(x)[0]
        ce = F.cross_entropy(logits.view(-1, logits.size(-1)), y.reshape(-1))
        loss = ce
        kd_val = None
        if teacher is not None and alpha > 0:
            with torch.no_grad():
                t_logits = teacher(x)[0]
            V = logits.size(-1)
            s_lp = F.log_softmax(logits.reshape(-1, V) / T, dim=-1)
            t_p = F.softmax(t_logits.reshape(-1, V) / T, dim=-1)
            kd = F.kl_div(s_lp, t_p, reduction="batchmean") * (T * T)
            loss = (1 - alpha) * ce + alpha * kd
            kd_val = kd.item()
        if proj is not None:
            _, _, hs = model(x, need_hidden=True)
            with torch.no_grad():
                _, _, ht = teacher(x, need_hidden=True)
            loss = loss + feat_weight * F.mse_loss(proj(hs), ht)

        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(params, 1.0)
        opt.step()
        hist.append(loss.item())

        if (it + 1) % log_every == 0 or it == 0:
            extra = ""
            if kd_val is not None:
                extra = "  ce %.4f  kd(T^2) %.4f" % (ce.item(), kd_val)
            print("  [%s] iter %4d/%d  loss %.4f%s  (%.1fs)" % (
                tag or "train", it + 1, iters, loss.item(), extra,
                time.time() - t0), flush=True)
    return hist, time.time() - t0


# ============================================================
# 6. 配置、工具与主流程
# ============================================================
TEACHER_CFG = dict(n_layer=2, n_head=4, n_embd=160, block_size=96, dropout=0.0)
STUDENT_CFG = dict(n_layer=2, n_head=4, n_embd=64, block_size=96, dropout=0.0)


def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def rss_mb():
    if psutil is None:
        return None
    return round(psutil.Process(os.getpid()).memory_info().rss / (1024 ** 2), 1)


def dump_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def load_state(path):
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")


def env_meta(args):
    return {
        "timestamp": now_iso(),
        "python": sys.version.split()[0],
        "torch": torch.__version__,
        "platform": platform.platform(),
        "cpu_count": os.cpu_count(),
        "threads": torch.get_num_threads(),
        "cuda_available": bool(torch.cuda.is_available()),
        "device": DEVICE,
        "seed": args.seed,
        "rss_mb": rss_mb(),
    }


def make_model(vocab_size, cfg, seed):
    torch.manual_seed(seed)
    return GPT(vocab_size, cfg)


def make_data(block):
    train_text = build_corpus(3000, seed=0)
    val_text = build_corpus(300, seed=999)
    tok = Tokenizer(train_text)
    train_ids = torch.tensor(tok.encode(train_text), dtype=torch.long)
    val_ids = torch.tensor(tok.encode(val_text), dtype=torch.long)
    return tok, train_ids, val_ids


def new_student(tok, seed):
    return make_model(tok.vocab_size, STUDENT_CFG, seed + 7)


def eval_student(model, teacher, val_ids, bs, block, name, hist, tcost,
                 T=None, alpha=0.0, feat=0.0, extra=None):
    v = evaluate(model, val_ids, bs, block)
    row = {
        "params": int(model.n_param),
        "val_loss": float(v),
        "ppl": float(math.exp(v)),
        "time_s": float(tcost),
        "curve": [float(x) for x in hist],
        "agree": float(agreement(model, teacher, val_ids, bs, block)),
        "T": T,
        "alpha": alpha,
        "feat": feat,
    }
    if extra:
        row.update(extra)
    print("[%s] val_loss=%.4f  ppl=%.2f  agree=%.3f  %.1fs" % (
        name, v, math.exp(v), row["agree"], tcost), flush=True)
    return row


def generate_text(model, tok, prompt="月", max_new=60,
                  temperature=0.9, top_k=20, seed=2024):
    torch.manual_seed(seed)
    ids = torch.tensor([tok.encode(prompt)], dtype=torch.long)
    with torch.no_grad():
        g = model.generate(ids, max_new, temperature=temperature, top_k=top_k)
    return tok.decode(g[0].tolist())


def teacher_forward(args, tok, train_ids, val_ids, out_dir):
    """训练或复用教师，返回 teacher、teacher_res、path。"""
    bs, block = args.batch_size, TEACHER_CFG["block_size"]
    teacher_path = os.path.join(out_dir, "teacher.pt")
    torch.manual_seed(args.seed)
    teacher = GPT(tok.vocab_size, TEACHER_CFG)
    print("[teacher] params = %.3f M" % (teacher.n_param / 1e6), flush=True)

    use_cache = (os.path.exists(teacher_path) and not args.retrain
                 and args.mode not in ("teacher", "quick"))
    if use_cache:
        teacher.load_state_dict(load_state(teacher_path))
        tv = evaluate(teacher, val_ids, bs, block)
        res = {
            "params": int(teacher.n_param),
            "val_loss": float(tv),
            "ppl": float(math.exp(tv)),
            "time_s": 0.0,
            "curve": [],
            "cached": True,
        }
        print("[teacher] 复用 %s  val_loss=%.4f  ppl=%.2f" % (
            os.path.basename(teacher_path), tv, math.exp(tv)), flush=True)
    else:
        th, ttime = train(teacher, train_ids, args.teacher_iters, bs, block,
                          lr=args.lr, seed=args.seed, log_every=args.log_every,
                          tag="teacher")
        tv = evaluate(teacher, val_ids, bs, block)
        torch.save(teacher.state_dict(), teacher_path)
        res = {
            "params": int(teacher.n_param),
            "val_loss": float(tv),
            "ppl": float(math.exp(tv)),
            "time_s": float(ttime),
            "curve": [float(x) for x in th],
            "cached": False,
        }
        print("[teacher] val_loss=%.4f  ppl=%.2f  %.1fs" % (
            tv, math.exp(tv), ttime), flush=True)
    return teacher, res, teacher_path


def run_all(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir):
    bs, block = args.batch_size, TEACHER_CFG["block_size"]
    torch.manual_seed(args.seed + 7)
    probe = GPT(tok.vocab_size, STUDENT_CFG)
    sp = int(probe.n_param)
    print("[student] params = %.3f M  (压缩率 %.1fx)" % (
        sp / 1e6, teacher.n_param / sp), flush=True)

    s0 = new_student(tok, args.seed)
    h0, t0 = train(s0, train_ids, args.student_iters, bs, block, lr=args.lr,
                   seed=args.seed, log_every=args.log_every, tag="scratch")
    row0 = eval_student(s0, teacher, val_ids, bs, block, "scratch", h0, t0,
                        T=None, alpha=0.0)

    s1 = new_student(tok, args.seed)
    h1, t1 = train(s1, train_ids, args.student_iters, bs, block, lr=args.lr,
                   seed=args.seed, teacher=teacher, T=args.T, alpha=args.alpha,
                   feat_weight=0.0, log_every=args.log_every, tag="kd")
    row1 = eval_student(s1, teacher, val_ids, bs, block, "kd", h1, t1,
                        T=args.T, alpha=args.alpha)

    samples = {
        "teacher": generate_text(teacher, tok, seed=2024),
        "scratch": generate_text(s0, tok, seed=2024),
        "kd": generate_text(s1, tok, seed=2024),
    }

    drop = row0["val_loss"] - row1["val_loss"]
    gap = row0["val_loss"] - teacher_res["val_loss"]
    res["scratch"] = row0
    res["kd"] = row1
    res["samples"] = samples
    res["comparison"] = {
        "loss_drop_abs": float(drop),
        "loss_drop_pct": float(100.0 * drop / row0["val_loss"]),
        "ppl_drop": float(row0["ppl"] - row1["ppl"]),
        "agree_gain": float(row1["agree"] - row0["agree"]),
        "gap_closure_pct": float(100.0 * drop / gap) if gap > 0 else None,
    }
    torch.save(s0.state_dict(), os.path.join(out_dir, "student_scratch.pt"))
    torch.save(s1.state_dict(), os.path.join(out_dir, "student_kd.pt"))

    print("\n[对比] 从零 %.4f -> 蒸馏 %.4f  相对下降 %.1f%%" % (
        row0["val_loss"], row1["val_loss"],
        100 * drop / row0["val_loss"]), flush=True)
    print("[sample/teacher] " + samples["teacher"].replace("\n", " "), flush=True)
    print("[sample/scratch] " + samples["scratch"].replace("\n", " "), flush=True)
    print("[sample/kd]      " + samples["kd"].replace("\n", " "), flush=True)
    return s0, s1


def run_ablate(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir):
    bs, block = args.batch_size, TEACHER_CFG["block_size"]
    grid_T = [1, 2, 4, 8]
    grid_a = [0.3, 0.5, 0.7, 0.9]
    V = tok.vocab_size
    gen = torch.Generator().manual_seed(2024)
    cache = []
    teacher.eval()
    with torch.no_grad():
        for _ in range(32):
            x, y = get_batch(train_ids, bs, block, gen)
            cache.append((x, y, teacher(x)[0]))

    rows = []
    t_start = time.time()
    for T in grid_T:
        for a in grid_a:
            torch.manual_seed(args.seed + 7)
            m = GPT(tok.vocab_size, STUDENT_CFG)
            opt = torch.optim.AdamW(m.parameters(), lr=args.lr, weight_decay=0.01)
            m.train()
            for it in range(args.abl_iters):
                x, y, tl = cache[it % len(cache)]
                logits = m(x)[0]
                ce = F.cross_entropy(logits.view(-1, V), y.reshape(-1))
                s_lp = F.log_softmax(logits.reshape(-1, V) / T, dim=-1)
                t_p = F.softmax(tl.reshape(-1, V) / T, dim=-1)
                kd = F.kl_div(s_lp, t_p, reduction="batchmean") * (T * T)
                loss = (1 - a) * ce + a * kd
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(m.parameters(), 1.0)
                opt.step()
            v = evaluate(m, val_ids, bs, block)
            print("  T=%d alpha=%.1f -> val %.4f" % (T, a, v), flush=True)
            rows.append({
                "T": int(T),
                "alpha": float(a),
                "val_loss": float(v),
                "ppl": float(math.exp(v)),
                "time_s": float(time.time() - t_start),
            })
    best = min(rows, key=lambda r: r["val_loss"])
    worst = max(rows, key=lambda r: r["val_loss"])
    res["ablation"] = rows
    res["best"] = best
    res["worst"] = worst
    res["meta"]["wall_time_s"] = float(time.time() - t_start)
    print("[ablate] 最优 T=%d alpha=%.1f val=%.4f | 最差 T=%d alpha=%.1f val=%.4f" % (
        best["T"], best["alpha"], best["val_loss"],
        worst["T"], worst["alpha"], worst["val_loss"]), flush=True)


def run_fitnet(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir):
    bs, block = args.batch_size, TEACHER_CFG["block_size"]
    torch.manual_seed(args.seed + 7)
    probe = GPT(tok.vocab_size, STUDENT_CFG)
    sp = int(probe.n_param)
    print("[fitnet] student params = %.3f M, feat_weight=%.3f" % (
        sp / 1e6, args.feat), flush=True)
    s = new_student(tok, args.seed)
    h, t = train(s, train_ids, args.student_iters, bs, block, lr=args.lr,
                 seed=args.seed, teacher=teacher, T=args.T, alpha=args.alpha,
                 feat_weight=args.feat, log_every=args.log_every, tag="fitnet")
    row = eval_student(s, teacher, val_ids, bs, block, "fitnet", h, t,
                       T=args.T, alpha=args.alpha, feat=args.feat)
    row["params_inference"] = sp
    proj_params = (STUDENT_CFG["n_embd"] * TEACHER_CFG["n_embd"]
                   + TEACHER_CFG["n_embd"])
    row["params_train_with_proj"] = int(sp + proj_params)
    torch.save(s.state_dict(), os.path.join(out_dir, "student_fitnet.pt"))
    res["fitnet"] = row
    # 读取主实验，便于报告直接比较
    all_path = os.path.join(out_dir, "results_all.json")
    if os.path.exists(all_path):
        with open(all_path, "r", encoding="utf-8") as f:
            main = json.load(f)
        for key in ("scratch", "kd"):
            if key in main:
                res[key] = main[key]
    return row


def run_selfkd(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir):
    bs, block = args.batch_size, TEACHER_CFG["block_size"]
    torch.manual_seed(args.seed + 7)
    probe = GPT(tok.vocab_size, STUDENT_CFG)
    sp = int(probe.n_param)
    print("[selfkd] same-arch teacher params = %.3f M, iters=%d" % (
        sp / 1e6, args.self_iters), flush=True)
    self_teacher = new_student(tok, args.seed)
    h_t, t_t = train(self_teacher, train_ids, args.self_iters, bs, block,
                     lr=args.lr, seed=args.seed, log_every=args.log_every,
                     tag="self-teacher")
    tv = evaluate(self_teacher, val_ids, bs, block)
    self_teacher_res = {
        "params": int(self_teacher.n_param),
        "iters": int(args.self_iters),
        "val_loss": float(tv),
        "ppl": float(math.exp(tv)),
        "time_s": float(t_t),
        "curve": [float(x) for x in h_t],
    }
    print("[self-teacher] val_loss=%.4f  ppl=%.2f" % (
        tv, math.exp(tv)), flush=True)
    torch.save(self_teacher.state_dict(), os.path.join(out_dir, "student_selfteacher.pt"))

    s = new_student(tok, args.seed)
    h, t = train(s, train_ids, args.student_iters, bs, block, lr=args.lr,
                 seed=args.seed, teacher=self_teacher, T=args.T, alpha=args.alpha,
                 log_every=args.log_every, tag="self-kd")
    row = eval_student(s, self_teacher, val_ids, bs, block, "self-kd", h, t,
                       T=args.T, alpha=args.alpha)
    torch.save(s.state_dict(), os.path.join(out_dir, "student_selfkd.pt"))
    res["self_teacher"] = self_teacher_res
    res["selfkd"] = row
    all_path = os.path.join(out_dir, "results_all.json")
    if os.path.exists(all_path):
        with open(all_path, "r", encoding="utf-8") as f:
            main = json.load(f)
        for key in ("scratch", "kd"):
            if key in main:
                res[key] = main[key]
    return row


def benchmark_latency(model, vocab_size, batch=24, block=96, warmup=20, runs=100):
    model.eval()
    x = torch.randint(0, vocab_size, (batch, block))
    with torch.no_grad():
        for _ in range(warmup):
            model(x)
        times = []
        for _ in range(runs):
            t0 = time.perf_counter()
            model(x)
            times.append((time.perf_counter() - t0) * 1000.0)
    times.sort()
    n = len(times)
    return {
        "median_ms": float(times[n // 2]),
        "mean_ms": float(sum(times) / n),
        "p90_ms": float(times[min(n - 1, int(0.9 * n))]),
    }


def run_quant(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir):
    bs, block = args.batch_size, TEACHER_CFG["block_size"]
    kd_path = os.path.join(out_dir, "student_kd.pt")
    if not os.path.exists(kd_path):
        raise FileNotFoundError("缺少 student_kd.pt，请先运行 --mode all")
    student = GPT(tok.vocab_size, STUDENT_CFG)
    student.load_state_dict(load_state(kd_path))
    student.eval()

    fp32_path = kd_path
    fp32_size = os.path.getsize(fp32_path) / (1024 ** 2)
    fp32_val = evaluate(student, val_ids, bs, block)
    fp32_lat = benchmark_latency(student, tok.vocab_size, bs, block)

    import torch.ao.quantization as tq
    q = tq.quantize_dynamic(student, {nn.Linear}, dtype=torch.qint8)
    q.eval()
    int8_path = os.path.join(out_dir, "student_int8.pt")
    torch.save(q.state_dict(), int8_path)
    int8_size = os.path.getsize(int8_path) / (1024 ** 2)
    int8_val = evaluate(q, val_ids, bs, block)
    int8_lat = benchmark_latency(q, tok.vocab_size, bs, block)
    top1 = agreement(q, student, val_ids, bs, block)

    res["quant"] = {
        "fp32_path": os.path.basename(fp32_path),
        "int8_path": os.path.basename(int8_path),
        "fp32_size_mb": float(fp32_size),
        "int8_size_mb": float(int8_size),
        "size_ratio": float(fp32_size / int8_size) if int8_size > 0 else None,
        "fp32_latency_ms": fp32_lat,
        "int8_latency_ms": int8_lat,
        "latency_speedup": float(fp32_lat["median_ms"] / int8_lat["median_ms"])
        if int8_lat["median_ms"] > 0 else None,
        "fp32_val_loss": float(fp32_val),
        "int8_val_loss": float(int8_val),
        "val_loss_delta": float(int8_val - fp32_val),
        "top1_agreement": float(top1),
    }
    print("[quant] size %.2f MB -> %.2f MB (%.2fx) | latency %.2f -> %.2f ms | "
          "val %.4f -> %.4f | top1 %.3f" % (
              fp32_size, int8_size, fp32_size / int8_size,
              fp32_lat["median_ms"], int8_lat["median_ms"],
              fp32_val, int8_val, top1), flush=True)
    return res["quant"]


def run_scale(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir):
    bs, block = args.batch_size, TEACHER_CFG["block_size"]
    widths = [96, 160, 256]
    scratch_val = None
    all_path = os.path.join(out_dir, "results_all.json")
    if os.path.exists(all_path):
        with open(all_path, "r", encoding="utf-8") as f:
            main = json.load(f)
        scratch_val = main.get("scratch", {}).get("val_loss")
    if scratch_val is None:
        print("[scale] 未找到主实验 scratch，先训练一个 120 步基线", flush=True)
        s0 = new_student(tok, args.seed)
        _, t0 = train(s0, train_ids, args.student_iters, bs, block, lr=args.lr,
                      seed=args.seed, log_every=args.log_every, tag="scale-scratch")
        scratch_val = evaluate(s0, val_ids, bs, block)

    rows = []
    for C in widths:
        tcfg = dict(n_layer=2, n_head=4, n_embd=C, block_size=96, dropout=0.0)
        if C == 160:
            t_model = teacher
            t_res = teacher_res
        else:
            t_path = os.path.join(out_dir, "teacher_C%d.pt" % C)
            t_model = make_model(tok.vocab_size, tcfg, args.seed)
            if os.path.exists(t_path) and not args.retrain:
                t_model.load_state_dict(load_state(t_path))
                tv = evaluate(t_model, val_ids, bs, block)
                t_res = {"params": int(t_model.n_param), "val_loss": float(tv),
                         "ppl": float(math.exp(tv)), "cached": True}
            else:
                _, tt = train(t_model, train_ids, args.teacher_iters, bs, block,
                              lr=args.lr, seed=args.seed, log_every=args.log_every,
                              tag="teacher-C%d" % C)
                tv = evaluate(t_model, val_ids, bs, block)
                torch.save(t_model.state_dict(), t_path)
                t_res = {"params": int(t_model.n_param), "val_loss": float(tv),
                         "ppl": float(math.exp(tv)), "time_s": float(tt),
                         "cached": False}
        print("[scale] C=%d teacher params=%.3f M val=%.4f" % (
            C, t_res["params"] / 1e6, t_res["val_loss"]), flush=True)

        if C == 160 and os.path.exists(all_path):
            with open(all_path, "r", encoding="utf-8") as f:
                main = json.load(f)
            kd_val = main.get("kd", {}).get("val_loss")
            kd_time = main.get("kd", {}).get("time_s", 0.0)
            kd_agree = main.get("kd", {}).get("agree")
            kd_params = main.get("kd", {}).get("params")
        else:
            s = make_model(tok.vocab_size, STUDENT_CFG, args.seed + 7)
            _, st = train(s, train_ids, args.student_iters, bs, block, lr=args.lr,
                          seed=args.seed, teacher=t_model, T=args.T,
                          alpha=args.alpha, log_every=args.log_every,
                          tag="student-C%d" % C)
            kd_val = evaluate(s, val_ids, bs, block)
            kd_time = st
            kd_agree = agreement(s, t_model, val_ids, bs, block)
            kd_params = int(s.n_param)
            torch.save(s.state_dict(), os.path.join(out_dir, "student_C%d.pt" % C))
            print("[scale] C=%d student val=%.4f agree=%.3f" % (
                C, kd_val, kd_agree), flush=True)

        gain = float(scratch_val - kd_val)
        rows.append({
            "C": int(C),
            "teacher_params": int(t_res["params"]),
            "teacher_val_loss": float(t_res["val_loss"]),
            "teacher_ppl": float(math.exp(t_res["val_loss"])),
            "scratch_val_loss": float(scratch_val),
            "kd_val_loss": float(kd_val),
            "kd_ppl": float(math.exp(kd_val)),
            "gain_abs": gain,
            "gain_pct": float(100.0 * gain / scratch_val),
            "kd_agree": float(kd_agree) if kd_agree is not None else None,
            "kd_time_s": float(kd_time) if kd_time is not None else None,
            "kd_params": int(kd_params) if kd_params is not None else None,
        })
    res["scale"] = rows
    print("[scale] " + " | ".join(
        "C=%d: %.4f->%.4f (+%.4f)" % (r["C"], r["scratch_val_loss"],
                                      r["kd_val_loss"], r["gain_abs"])
        for r in rows), flush=True)
    return rows


def run(args):
    out_dir = args.out_dir or OUT_DIR
    if args.mode == "quick":
        out_dir = os.path.join(OUT_DIR, "quick")
        args.teacher_iters = 30
        args.student_iters = 20
        args.abl_iters = 10
        args.batch_size = 8
        args.log_every = 10
        args.mode = "all"
        print("[quick] 自检模式：极小步数，结果不写入报告", flush=True)
    if args.mode == "fitnet" and args.feat <= 0:
        args.feat = 0.1
    os.makedirs(out_dir, exist_ok=True)
    torch.set_num_threads(max(1, args.threads))
    torch.manual_seed(args.seed)

    t_start = time.time()
    tok, train_ids, val_ids = make_data(TEACHER_CFG["block_size"])
    bs, block = args.batch_size, TEACHER_CFG["block_size"]
    print("[data] vocab=%d  train_chars=%d  val_chars=%d  block=%d  batch=%d" % (
        tok.vocab_size, len(train_ids), len(val_ids), block, bs), flush=True)
    print("[env] python=%s torch=%s threads=%d cuda_available=%s" % (
        sys.version.split()[0], torch.__version__, torch.get_num_threads(),
        torch.cuda.is_available()), flush=True)

    res = {
        "meta": env_meta(args),
        "data": {
            "vocab": int(tok.vocab_size),
            "train_chars": int(len(train_ids)),
            "val_chars": int(len(val_ids)),
            "block": int(block),
            "batch": int(bs),
        },
        "config": {
            "teacher": dict(TEACHER_CFG),
            "student": dict(STUDENT_CFG),
            "teacher_iters": int(args.teacher_iters),
            "student_iters": int(args.student_iters),
            "abl_iters": int(args.abl_iters),
            "lr": float(args.lr),
            "T": float(args.T),
            "alpha": float(args.alpha),
            "feat": float(args.feat),
            "seed": int(args.seed),
            "threads": int(args.threads),
        },
    }

    teacher, teacher_res, teacher_path = teacher_forward(
        args, tok, train_ids, val_ids, out_dir)
    res["teacher"] = teacher_res
    res["meta"]["wall_time_s"] = float(time.time() - t_start)

    if args.mode == "teacher":
        dump_json(os.path.join(out_dir, "results_teacher.json"), res)
        print("\n[done] 教师结果写入 %s" % out_dir, flush=True)
        return

    if args.mode == "ablate":
        run_ablate(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir)
        res["meta"]["wall_time_s"] = float(time.time() - t_start)
        dump_json(os.path.join(out_dir, "results_ablate.json"), res)
        print("\n[done] 消融结果写入 %s" % out_dir, flush=True)
        return

    if args.mode == "all":
        run_all(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir)
    elif args.mode == "fitnet":
        run_fitnet(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir)
    elif args.mode == "selfkd":
        run_selfkd(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir)
    elif args.mode == "quant":
        run_quant(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir)
    elif args.mode == "scale":
        run_scale(args, tok, train_ids, val_ids, teacher, teacher_res, res, out_dir)
    else:
        raise ValueError("未知 mode: %s" % args.mode)

    res["meta"]["wall_time_s"] = float(time.time() - t_start)
    res["meta"]["rss_mb"] = rss_mb()
    tag = args.mode
    dump_json(os.path.join(out_dir, "results_%s.json" % tag), res)
    print("\n[done] 结果写入 %s" % out_dir, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="all",
                    choices=["quick", "teacher", "all", "ablate",
                             "fitnet", "selfkd", "quant", "scale"])
    ap.add_argument("--teacher-iters", type=int, default=200)
    ap.add_argument("--student-iters", type=int, default=120)
    ap.add_argument("--abl-iters", type=int, default=80)
    ap.add_argument("--self-iters", type=int, default=200)
    ap.add_argument("--batch-size", type=int, default=24)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--T", type=float, default=4.0)
    ap.add_argument("--alpha", type=float, default=0.5)
    ap.add_argument("--feat", type=float, default=0.0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--retrain", action="store_true",
                    help="忽略已缓存的 teacher.pt，重新训练教师")
    ap.add_argument("--log-every", type=int, default=50)
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()
    run(args)


if __name__ == "__main__":
    main()
